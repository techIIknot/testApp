/* eslint-disable no-trailing-spaces */
/* eslint-disable eol-last */
/* eslint-disable comma-dangle */
/* eslint-disable semi */
import { StyleSheet } from 'react-native'

const globalStyle = StyleSheet.create({
    container:{
        flex: 1,
        alignItems: 'center',
        justifyContent:'center'
    },
    bgPrimary:{
        backgroundColor:'#383535'
    },
    colorPrimary:{
        color:'#fff'
    }
})

export default  globalStyle 
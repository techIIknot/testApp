import React, {useState, useEffect} from 'react';
import {View, Text, StyleSheet} from 'react-native';
import moment from 'moment';

const Countdown = ({targetDate}) => {
  const calculateRemainingTime = targetDate => {
    const now = moment();
    const target = moment(targetDate);
    const diff = target.diff(now);

    const duration = moment.duration(diff);
    const days = Math.floor(duration.asDays());
    const hours = duration.hours();
    const minutes = duration.minutes();
    const seconds = duration.seconds();

    return {
      days,
      hours,
      minutes,
      seconds,
    };
  };

  const [remainingTime, setRemainingTime] = useState(
    calculateRemainingTime(targetDate),
  );

  useEffect(() => {
    const interval = setInterval(() => {
      setRemainingTime(calculateRemainingTime(targetDate));
    }, 1000);

    // Clear the interval when the component is unmounted
    return () => clearInterval(interval);
  }, [targetDate]);

  return (
    <View style={styles.container}>
      <View style={styles.box}>
        <Text style={styles.label}>Days</Text>
        <Text style={styles.value}>{remainingTime.days}</Text>
      </View>
      <View style={styles.box}>
        <Text style={styles.label}>Hours</Text>
        <Text style={styles.value}>{remainingTime.hours}</Text>
      </View>
      <View style={styles.box}>
        <Text style={styles.label}>Minutes</Text>
        <Text style={styles.value}>{remainingTime.minutes}</Text>
      </View>
      <View style={styles.box}>
        <Text style={styles.label}>Seconds</Text>
        <Text style={styles.value}>{remainingTime.seconds}</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
  },
  box: {
    alignItems: 'center',
  },
  label: {
    fontSize: 12,
    color: 'gray',
  },
  value: {
    fontSize: 20,
    fontWeight: 'bold',
    color: 'blue',
  },
});

export default Countdown;

import {ADD_COUNTDOWN, ADD_REGISTER, USER_FOUND} from '../constants';

export const changeUserLoginStatus = payload => {
  return {
    type: USER_FOUND,
    payload,
  };
};

export const addRegister = payload => {
  return {
    type: ADD_REGISTER,
    payload,
  };
};

export const addCountDown = payload => {
  return {
    type: ADD_COUNTDOWN,
    payload,
  };
};

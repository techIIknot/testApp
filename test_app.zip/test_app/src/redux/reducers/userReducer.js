import {ADD_COUNTDOWN, ADD_REGISTER, USER_FOUND} from '../constants';

const initialState = {
  userFound: false,
  registerList: [],
  countDownList: [],
};
const userReducer = (state = initialState, {type, payload}) => {
  switch (type) {
    case USER_FOUND:
      return {...state, userFound: payload};

    case ADD_REGISTER:
      return {...state, registerList: [...state.registerList, payload]};

    case ADD_COUNTDOWN:
      return {
        ...state,
        countDownList: payload?.isEditing
          ? state.countDownList?.map(cd => {
              if (payload.data.id === cd.id) {
                return payload.data;
              } else {
                return cd;
              }
            })
          : [...state.countDownList, payload.data],
      };

    default:
      return state;
  }
};

export default userReducer;

export const USER_FOUND = 'USER_FOUND';
export const ADD_REGISTER = 'ADD_REGISTER';
export const ADD_COUNTDOWN = 'ADD_COUNTDOWN';

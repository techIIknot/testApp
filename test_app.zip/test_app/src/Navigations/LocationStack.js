/* eslint-disable eol-last */
/* eslint-disable semi */
import React from 'react'
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import Location from '../screens/Location/Location';

const Stack = createNativeStackNavigator();
const LocationStack = () => {
  return (
    <Stack.Navigator screenOptions={{headerShown: false}}>
      <Stack.Screen name="LocationScreen" component={Location} />
    </Stack.Navigator>
  )
}

export default LocationStack
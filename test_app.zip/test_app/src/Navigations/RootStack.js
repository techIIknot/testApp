import React from 'react';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import SplashScreen from '../screens/splashscreen/SplashScreen';
import AuthStack from './AuthStack';
import SideDrawer from './SideDrawer';
import {useSelector} from 'react-redux';

const Stack = createNativeStackNavigator();

const RootStack = () => {
  const {userFound} = useSelector(store => store.userReducer);

  return (
    <Stack.Navigator screenOptions={{headerShown: false}}>
      <Stack.Screen name="SplashScreen" component={SplashScreen} />
      {userFound ? (
        <Stack.Screen name="SideDrawer" component={SideDrawer} />
      ) : (
        <Stack.Screen name="AuthStack" component={AuthStack} />
      )}
    </Stack.Navigator>
  );
};

export default RootStack;

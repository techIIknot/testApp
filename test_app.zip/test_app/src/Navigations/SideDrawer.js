/* eslint-disable comma-dangle */
/* eslint-disable no-unused-vars */
import React from 'react';
import {
  createDrawerNavigator,
} from '@react-navigation/drawer';
import BottomTab from './BottomTab';

const Drawer = createDrawerNavigator();

const SideDrawer = () => {
  return (
    <Drawer.Navigator
      screenOptions={{
        headerTitle: '',
        headerStyle: {
          backgroundColor: '#383535',
        },
        headerTintColor: '#fff',
      }}>
      <Drawer.Screen
        name="BottomTab"
        component={BottomTab}
        options={{
          drawerLabel: 'Home',
        }}
      />
    </Drawer.Navigator>
  );
};

export default SideDrawer;

/* eslint-disable eol-last */
/* eslint-disable semi */
import React from 'react';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import VisitingCardListing from '../screens/visitingcardlisting/VisitingCardListing';
import RegisterScreen from '../screens/registerscreen/RegisterScreen';
import ViewCard from '../screens/viewcard/ViewCard';

const Stack = createNativeStackNavigator();
const VisitingCardStack = () => {
  return (
    <Stack.Navigator screenOptions={{headerShown: false}}>
      <Stack.Screen name="VisitingCardListing" component={VisitingCardListing} />
      <Stack.Screen name="RegisterScreen" component={RegisterScreen} />
      <Stack.Screen name="ViewCard" component={ViewCard} />
    </Stack.Navigator>
  );
};

export default VisitingCardStack;

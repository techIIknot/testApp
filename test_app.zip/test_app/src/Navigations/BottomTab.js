/* eslint-disable eol-last */
/* eslint-disable semi */
import React from 'react';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import UserStack from './UserStack';
import CountDownStack from './CountDownStack';
import VisitingCardStack from './VisitingCardStack';
import LocationStack from './LocationStack';

const Tab = createBottomTabNavigator();

const BottomTab = () => {
  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarIconStyle: {display: 'none'},
        tabBarStyle: { backgroundColor: '#383535' },
        tabBarActiveBackgroundColor:'#5ca752',
        tabBarActiveTintColor:'#fff',
        tabBarLabelStyle:{fontSize:16,fontWeight:'bold'},
        tabBarItemStyle:{display:'flex',alignItems:'center',justifyContent:'center'}
      }}>
      <Tab.Screen name="User" component={UserStack} />
      <Tab.Screen name="Countdown" component={CountDownStack} />
      <Tab.Screen name="Card" component={VisitingCardStack} />
      <Tab.Screen name="Location" component={LocationStack} />
    </Tab.Navigator>
  );
};

export default BottomTab;

/* eslint-disable eol-last */
/* eslint-disable semi */
import React from 'react';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import CountDownListing from '../screens/countdownlisting/CountDownListing';
import CreateCountDown from '../screens/createcountdown/CreateCountDown';

const Stack = createNativeStackNavigator();
const CountDownStack = () => {
  return (
    <Stack.Navigator screenOptions={{headerShown: false}}>
      <Stack.Screen name="CountDownListing" component={CountDownListing} />
      <Stack.Screen name="CreateCountDown" component={CreateCountDown} />
    </Stack.Navigator>
  );
};

export default CountDownStack;

/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable react-native/no-inline-styles */
import {View, Text, Pressable} from 'react-native';
import React, {useEffect, useState} from 'react';
import {
  TextInput,
  Button,
  IconButton,
  MD3Colors,
  Modal,
  Portal,
} from 'react-native-paper';
import {DatePickerModal, TimePickerModal} from 'react-native-paper-dates';
import moment from 'moment';
import EmojiPicker from 'rn-emoji-keyboard';
import {useDispatch} from 'react-redux';
import {addCountDown} from '../../redux/actions';
import {v4 as uuidv4} from 'uuid';
import randomColor from 'randomcolor';
import ColorPicker from 'react-native-wheel-color-picker';
import CountDownTimer from '../../components/CountDownTimer';

const CreateCountDown = ({navigation, route}) => {
  const [countDownData, setCountDownData] = useState({
    title: '',
    date: '',
    time: '',
    emoji: '😀',
    bgColor: '',
    id: '',
  });
  const [openDate, setOpenDate] = useState(false);
  const [openTime, setOpenTime] = useState(false);
  const [openEmoji, setOpenEmoji] = useState(false);
  const [openColorPicker, setOpenColorPicker] = useState(false);
  const [timerData, setTimerData] = useState({
    date: '',
    time: '',
  });

  const {isEditing, activeCountDown} = route.params;

  useEffect(() => {
    if (isEditing) {
      setCountDownData({
        title: activeCountDown?.title,
        date: activeCountDown?.timerData?.date,
        time: activeCountDown?.timerData?.time,
        emoji: activeCountDown?.emoji,
        bgColor: activeCountDown.bgColor,
        id: activeCountDown.id,
      });
    }
  }, []);

  const dispatch = useDispatch();

  const onDismissSingle = () => {
    setOpenDate(false);
  };

  const onConfirmSingle = params => {
    setOpenDate(false);
    setTimerData({
      ...timerData,
      date: moment(params.date).format('YYYY-MM-DD'),
    });
    setCountDownData({
      ...countDownData,
      date: moment(params.date).format('YYYY-MM-DD'),
    });
  };

  const onDismissTime = () => {
    setOpenTime(false);
  };

  const onConfirmTime = ({hours, minutes}) => {
    setOpenTime(false);
    setTimerData({...timerData, time: `${hours}:${minutes}:59`});
    setCountDownData({
      ...countDownData,
      time:
        hours > 12 ? `${hours - 12}:${minutes} pm` : `${hours}:${minutes} am`,
    });
  };

  const selectEmoji = emojiObject => {
    setCountDownData({...countDownData, emoji: emojiObject?.emoji});
  };

  const startCountDown = () => {
    dispatch(
      addCountDown({
        isEditing,
        data: {
          ...countDownData,
          id: isEditing ? countDownData?.id : uuidv4(),
          bgColor: isEditing ? countDownData?.bgColor : randomColor(),
          timerData,
        },
      }),
    );
    navigation.navigate('CountDownListing');
  };

  const onColorChange = color => {
    setCountDownData({...countDownData, bgColor: color});
  };

  return (
    <View>
      <View style={{padding: 20}}>
        <View style={{alignItems: 'flex-end'}}>
          <Pressable onPress={() => setOpenColorPicker(true)}>
            <Text
              style={{
                color: '#fff',
                backgroundColor: 'tomato',
                paddingHorizontal: 5,
                borderRadius: 50,
              }}>
              Pick Color
            </Text>
          </Pressable>
        </View>
        <View style={{position: 'relative', marginBottom: 20}}>
          <Text style={{fontSize: 100, textAlign: 'center'}}>
            {countDownData?.emoji}
          </Text>
          <IconButton
            icon="pencil"
            iconColor={MD3Colors.error50}
            size={30}
            onPress={() => setOpenEmoji(true)}
            style={{position: 'absolute', bottom: -10, left: '55%'}}
          />
        </View>
        <TextInput
          mode="outlined"
          label="Title"
          placeholder="Enter title"
          onChangeText={value =>
            setCountDownData({...countDownData, title: value})
          }
          value={countDownData?.title}
        />
        <Text
          style={{
            textAlign: 'center',
            marginVertical: 20,
            backgroundColor: '#fff',
            padding: 15,
            color: '#000',
            borderWidth: 1,
            borderStyle: 'solid',
            borderColor: 'rgba(0,0,0,0.5)',
            borderRadius: 5,
          }}>
          {countDownData?.date ? countDownData?.date : 'DD-MM-YYYY'}{' '}
          {countDownData?.time ? countDownData?.time : 'hh:mm'}
        </Text>
        <View
          style={{
            flexDirection: 'row',
            justifyContent: 'space-around',
            alignItems: 'center',
          }}>
          <Button
            onPress={() => setOpenDate(true)}
            uppercase={false}
            mode="outlined">
            Pick Date
          </Button>
          <Button
            onPress={() => setOpenTime(true)}
            uppercase={false}
            mode="outlined">
            Pick Time
          </Button>
        </View>
        {timerData.date && timerData.time ? (
          <CountDownTimer targetDate={`${timerData.date}T${timerData.time}`} />
        ) : null}
        <View style={{marginVertical: 20}}>
          <Button uppercase={false} mode="outlined" onPress={startCountDown}>
            {isEditing ? 'Edit Countdown' : 'Start Countdown'}
          </Button>
        </View>
      </View>
      <DatePickerModal
        locale="en"
        mode="single"
        visible={openDate}
        onDismiss={onDismissSingle}
        date={countDownData?.date}
        onConfirm={onConfirmSingle}
      />

      <TimePickerModal
        visible={openTime}
        onDismiss={onDismissTime}
        onConfirm={onConfirmTime}
        hours={0}
        minutes={0}
        use24HourClock={false}
      />
      <EmojiPicker
        onEmojiSelected={selectEmoji}
        open={openEmoji}
        onClose={() => setOpenEmoji(false)}
      />
      <Portal>
        <Modal
          visible={openColorPicker}
          onDismiss={() => setOpenColorPicker(false)}
          style={{backgroundColor: 'rgba(0,0,0,0.5)', padding: 20}}>
          <View
            style={{
              backgroundColor: '#fff',
              marginTop: 70,
              padding: 24,
              height: '80%',
              width: '100%',
            }}>
            <ColorPicker
              color={countDownData?.bgColor}
              onColorChange={color => onColorChange(color)}
              thumbSize={30}
              sliderSize={30}
              noSnap={true}
              row={false}
              hideSliders
              style={{flex: 1}}
            />
          </View>
        </Modal>
      </Portal>
    </View>
  );
};

export default CreateCountDown;

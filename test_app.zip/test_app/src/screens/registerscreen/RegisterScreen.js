/* eslint-disable react-native/no-inline-styles */

import {StyleSheet, View} from 'react-native';
import React, {useState} from 'react';
import {TextInput, Button} from 'react-native-paper';
import {useDispatch} from 'react-redux';
import {addRegister} from '../../redux/actions';
import {v4 as uuidv4} from 'uuid';

const RegisterScreen = ({navigation}) => {
  const [registerData, setRegisterData] = useState({
    name: '',
    designation: '',
    phone: '',
    website: '',
    email: '',
    address: '',
  });

  const dispatch = useDispatch();

  const submitRegisterData = () => {
    dispatch(addRegister({...registerData, id: uuidv4()}));
    navigation.navigate('VisitingCardListing');
  };

  return (
    <View style={{flex: 1}}>
      <View style={{padding: 20}}>
        <TextInput
          mode="outlined"
          label="Name"
          placeholder="Enter Name"
          style={style.inputField}
          value={registerData?.name}
          onChangeText={value =>
            setRegisterData({...registerData, name: value})
          }
        />
        <TextInput
          mode="outlined"
          label="Designation"
          placeholder="Enter Designation"
          style={style.inputField}
          value={registerData?.designation}
          onChangeText={value =>
            setRegisterData({...registerData, designation: value})
          }
        />
        <TextInput
          mode="outlined"
          label="Phone"
          placeholder="Enter Phone Number"
          style={style.inputField}
          value={registerData?.phone}
          onChangeText={value =>
            setRegisterData({...registerData, phone: value})
          }
        />
        <TextInput
          mode="outlined"
          label="Website"
          placeholder="Enter Website"
          style={style.inputField}
          value={registerData?.website}
          onChangeText={value =>
            setRegisterData({...registerData, website: value})
          }
        />
        <TextInput
          mode="outlined"
          label="Email"
          placeholder="Enter Email"
          style={style.inputField}
          value={registerData?.email}
          onChangeText={value =>
            setRegisterData({...registerData, email: value})
          }
        />
        <TextInput
          mode="outlined"
          label="Address"
          placeholder="Enter Address"
          style={style.inputField}
          value={registerData?.address}
          onChangeText={value =>
            setRegisterData({...registerData, address: value})
          }
        />
      </View>
      <View style={{paddingHorizontal: 20}}>
        <Button uppercase={false} mode="outlined" onPress={submitRegisterData}>
          Save
        </Button>
      </View>
    </View>
  );
};

const style = StyleSheet.create({
  inputField: {
    marginBottom: 10,
  },
});

export default RegisterScreen;

/* eslint-disable react-native/no-inline-styles */
/* eslint-disable eol-last */
/* eslint-disable semi */
import {Pressable, Text, View, FlatList} from 'react-native';
import React from 'react';
import {useSelector} from 'react-redux';
import CountDownTimer from '../../components/CountDownTimer';

const CountDownListing = ({navigation}) => {
  const {countDownList} = useSelector(store => store.userReducer);
  return (
    <View style={{flex: 1, position: 'relative'}}>
      <View style={{padding: 10}}>
        <FlatList
          data={countDownList}
          renderItem={({item}) => (
            <Pressable
              onPress={() =>
                navigation.navigate('CreateCountDown', {
                  isEditing: true,
                  activeCountDown: item,
                })
              }
              style={{
                padding: 10,
                backgroundColor: item.bgColor,
                marginBottom: 10,
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'flex-start',
              }}>
              <View style={{paddingHorizontal: 8}}>
                <Text style={{fontSize: 30}}>{item.emoji}</Text>
              </View>
              <View style={{paddingHorizontal: 8}}>
                <Text style={{color: '#fff', fontSize: 20, fontWeight: 'bold'}}>
                  {item.title}
                </Text>
                <Text style={{color: '#fff', fontSize: 14, fontWeight: 'bold'}}>
                  {item.date} {item.time}
                </Text>
              </View>
              <View>
                <CountDownTimer
                  targetDate={`${item?.timerData?.date}T${item?.timerData?.time}`}
                />
              </View>
            </Pressable>
          )}
          keyExtractor={item => item.id}
        />
      </View>
      <Pressable
        onPress={() =>
          navigation.navigate('CreateCountDown', {
            isEditing: false,
            activeCountDown: {},
          })
        }
        style={{
          width: 50,
          height: 50,
          backgroundColor: '#5ca752',
          borderRadius: 50,
          paddingTop: 5,
          position: 'absolute',
          bottom: 20,
          right: 20,
        }}>
        <Text
          style={{
            fontSize: 30,
            fontWeight: 'bold',
            textAlign: 'center',
            verticalAlign: 'middle',
            color: '#fff',
          }}>
          +
        </Text>
      </Pressable>
    </View>
  );
};

export default CountDownListing;

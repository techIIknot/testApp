/* eslint-disable eol-last */
/* eslint-disable semi */
import {SafeAreaView, View, FlatList, StyleSheet, Text} from 'react-native';
import React, {useEffect, useState} from 'react';
import axios from 'axios';
import {v4 as uuidv4} from 'uuid';

const UsersListing = () => {
  const [allUsers, setAllUsers] = useState([]);
  useEffect(() => {
    axios
      .get('https://randomuser.me/api/?results=100&inc=name')
      .then(res => {
        setAllUsers(
          res.data.results.map(rs => {
            return {...rs, id: uuidv4()};
          }),
        );
      })
      .catch(err => console.log(err));
  }, []);

  return (
    <SafeAreaView style={styles.container}>
      <FlatList
        data={allUsers}
        renderItem={({item}) => (
          <View style={styles.item}>
            <Text style={styles.fullName}>
              {item.name.title} {item.name.first} {item.name.last}
            </Text>
            <Text style={styles.title}>Title:{item.name.title}</Text>
            <Text style={styles.title}>First:{item.name.first}</Text>
            <Text style={styles.title}>Last:{item.name.last}</Text>
          </View>
        )}
        keyExtractor={item => item.id}
      />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    // marginTop: StatusBar.currentHeight || 0,
  },
  item: {
    backgroundColor: 'tomato',
    padding: 20,
    marginVertical: 8,
    marginHorizontal: 16,
  },
  title: {
    fontSize: 14,
  },
  fullName: {
    fontSize: 20,
    fontWeight: 'bold',
  },
});

export default UsersListing;

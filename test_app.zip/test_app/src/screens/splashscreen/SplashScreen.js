/* eslint-disable react-hooks/exhaustive-deps */
import {Text, View} from 'react-native';
import React, {useEffect} from 'react';
import globalStyle from '../../stylesheet/Globel';
import {useSelector} from 'react-redux';

const SplashScreen = ({navigation}) => {
  const {userFound} = useSelector(store => store.userReducer);
  useEffect(() => {
    setTimeout(() => {
      navigation.replace(userFound ? 'SideDrawer' : 'AuthStack');
    }, 2000);
  }, []);

  return (
    <View style={globalStyle.container}>
      <Text>SplashScreen</Text>
    </View>
  );
};

export default SplashScreen;

/* eslint-disable react-native/no-inline-styles */
import {Text, View} from 'react-native';
import React, {useState} from 'react';
import {Button, TextInput} from 'react-native-paper';
import {changeUserLoginStatus} from '../../redux/actions';
import {useDispatch} from 'react-redux';

const LoginScreen = () => {
  const [loginData, setLoginData] = useState({
    email: '',
    password: '',
  });
  const [loginError, setLoginError] = useState('');
  const [hidePass, setHidePass] = useState(true);

  const dispatch = useDispatch();

  const checkValidation = () => {
    const emailPattern =
      /[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/g;
    const emailCheck = emailPattern.test(loginData?.email);
    const passwordPattern =
      /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[a-zA-Z]).{8,}$/gm;
    const passwordCheck = passwordPattern.test(loginData?.password);
    if (emailCheck && passwordCheck) {
      dispatch(changeUserLoginStatus(true));
    } else {
      setLoginError('Please enter valid email and password');
    }
  };

  return (
    <View
      style={{
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'rgba(0,0,0,0.8)',
      }}>
      <View
        style={{
          backgroundColor: 'rgba(255,255,255,1)',
          padding: 20,
          borderRadius: 10,
          width: '90%',
        }}>
        <TextInput
          mode="outlined"
          label="Email"
          value={loginData?.email}
          onChangeText={value => setLoginData({...loginData, email: value})}
          style={{marginBottom: 10}}
        />
        <TextInput
          mode="outlined"
          label="Password"
          value={loginData?.password}
          onChangeText={value => setLoginData({...loginData, password: value})}
          style={{marginBottom: 10}}
          secureTextEntry={hidePass ? true : false}
          right={
            <TextInput.Icon
              name="eye"
              onPress={() => setHidePass(!hidePass)}
            />
          }
        />
        <Button onPress={checkValidation} mode="outlined" uppercase={false}>
          Login
        </Button>
        {loginError ? (
          <Text style={{color: 'red', textAlign: 'center',marginTop:10}}>{loginError}</Text>
        ) : null}
      </View>
    </View>
  );
};

export default LoginScreen;

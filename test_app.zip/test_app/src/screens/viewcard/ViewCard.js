/* eslint-disable react-native/no-inline-styles */
import {
  View,
  Text,
  ImageBackground,
} from 'react-native';
import React, {useRef} from 'react';
import {Button} from 'react-native-paper';
import ViewShot from 'react-native-view-shot';
import Share from 'react-native-share';
const cardBg = require('../../assets/cardBg.jpg');

const ViewCard = ({route}) => {
  const viewRef = useRef();
  const {item} = route.params;

  const shareImage = async () => {
    viewRef.current
      .capture()
      .then(async uri => {
        const shareResponse = await Share.open({url: uri});
      })
      .catch(err => console.log(err));
  };

  return (
    <View style={{flex: 1, padding: 10}}>
      <ViewShot ref={viewRef} options={{format: 'jpg', quality: 0.9}}>
        <ImageBackground
          source={cardBg}
          resizeMode="cover"
          style={{padding: 20, marginBottom: 20}}>
          <View style={{width: '60%'}}>
            <Text style={{color: '#fff', fontSize: 25, fontWeight: 'bold'}}>
              {item?.name}
            </Text>
            <Text style={{color: '#fff', fontSize: 16, marginBottom: 20}}>
              {item?.designation}
            </Text>
            <Text style={{color: '#fff', fontSize: 16, marginBottom: 10}}>
              {item?.phone}
            </Text>
            <Text style={{color: '#fff', fontSize: 16, marginBottom: 10}}>
              {item?.website}
            </Text>
            <Text style={{color: '#fff', fontSize: 16, marginBottom: 10}}>
              {item?.email}
            </Text>
            <Text style={{color: '#fff', fontSize: 16, marginBottom: 10}}>
              {item?.address}
            </Text>
          </View>
        </ImageBackground>
      </ViewShot>
      <Button uppercase={false} mode="outlined" onPress={shareImage}>
        Share
      </Button>
    </View>
  );
};

export default ViewCard;

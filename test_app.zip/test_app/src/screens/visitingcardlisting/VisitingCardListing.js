/* eslint-disable react-native/no-inline-styles */
/* eslint-disable eol-last */
/* eslint-disable semi */
import {Pressable, Text, View, FlatList} from 'react-native';
import React from 'react';
import {useSelector} from 'react-redux';

const VisitingCardListing = ({navigation}) => {
  const {registerList} = useSelector(store => store.userReducer);
  return (
    <View style={{flex: 1, position: 'relative'}}>
      <View style={{padding: 10}}>
        <FlatList
          data={registerList}
          renderItem={({item}) => {
            let n = (Math.random() * 0xfffff * 1000000).toString(16);
            let randomHexCode = n.slice(0, 6);
            return (
              <Pressable
                onPress={() => navigation.navigate('ViewCard', {item})}
                style={{
                  padding: 10,
                  backgroundColor: `#${randomHexCode}`,
                  marginBottom: 10,
                }}>
                <Text style={{color: '#fff', fontSize: 20, fontWeight: 'bold',textTransform:'capitalize'}}>
                  {item.name}
                </Text>
              </Pressable>
            );
          }}
          keyExtractor={item => item.id}
        />
      </View>
      <Pressable
        onPress={() => navigation.navigate('RegisterScreen')}
        style={{
          width: 50,
          height: 50,
          backgroundColor: '#5ca752',
          borderRadius: 50,
          paddingTop: 5,
          position: 'absolute',
          bottom: 20,
          right: 20,
        }}>
        <Text
          style={{
            fontSize: 30,
            fontWeight: 'bold',
            textAlign: 'center',
            verticalAlign: 'middle',
            color: '#fff',
          }}>
          +
        </Text>
      </Pressable>
    </View>
  );
};

export default VisitingCardListing;
